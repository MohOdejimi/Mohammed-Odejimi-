console.log('Hello Dcoder')
let menu = document.querySelector('#menu_btn');
let navmenu = document.querySelector('nav');
menu.onClick =  ()  => {
  menu.classList.toggle('#menu_btn')
  navmenu.classList.toggle('open');
}